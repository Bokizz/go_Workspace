package temporary2

import "strings"

func WhenListen(s string) string {
	return "When he listened he heard: " + strings.ToUpper(s)
}
