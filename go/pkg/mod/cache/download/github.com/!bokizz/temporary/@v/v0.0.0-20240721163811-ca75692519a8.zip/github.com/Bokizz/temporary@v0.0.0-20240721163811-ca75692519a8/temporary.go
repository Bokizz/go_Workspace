package temporary

func Hey() string {
	return "Hey,hey!"
}

func Listen() string {
	return "Listen,hey!"
}
